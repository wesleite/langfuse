import json
import os

import boto3
from botocore.exceptions import ClientError

eks = boto3.client('eks')
ssm = boto3.client('ssm')


def base_name(nodegroup_name):
    return nodegroup_name.split("-", 1)[0]


def param_name(cluster, base):
    return f"/eks/{cluster}/{base}/nodegroup_config"


def load_scale_config(cluster, nodegroup):
    name = param_name(cluster, base_name(nodegroup))
    try:
        val = ssm.get_parameter(Name=name)['Parameter']['Value']
        print(f"📦 Loaded scaling config from SSM: {name}")
        return json.loads(val)
    except ssm.exceptions.ParameterNotFound:
        print(f"⚠️ Missing SSM config: {name} (skip)")
        return None


def scaling_config_changed(desc, desired_min, desired_max, desired_desired):
    cfg = desc['scalingConfig']
    return not (cfg['minSize'] == desired_min and
                cfg['maxSize'] == desired_max and
                cfg['desiredSize'] == desired_desired)


def lambda_handler(event, context):
    action = (event.get("action") or os.getenv("ACTION", "")).lower()
    cluster_prefix = os.getenv("CLUSTER_PREFIX", None)

    if action not in ("up", "down"):
        return {"error": "Use action=up or action=down"}

    clusters = eks.list_clusters()['clusters']

    for cluster in clusters:
        if cluster_prefix and not cluster.startswith(cluster_prefix):
            continue

        nodegroups = eks.list_nodegroups(clusterName=cluster)['nodegroups']

        for ng in nodegroups:
            desc = eks.describe_nodegroup(
                clusterName=cluster,
                nodegroupName=ng
            )['nodegroup']

            tags = desc.get('tags', {})
            if tags.get('PowerSaveEnabled', 'false').lower() != 'true':
                continue
            if ng.startswith("default"):
                continue
            if ng.startswith("gitlab"):
                continue

            existing_labels = desc.get("labels", {})
            existing_taints = desc.get("taints", [])
            powersave_taint = {"key": "powersave", "value": "true", "effect": "NO_SCHEDULE"}

            if action == "down":
                remove_labels = list(existing_labels.keys())
                remove_taints = [t for t in existing_taints if t != powersave_taint]
                add_taints = [powersave_taint] if powersave_taint not in existing_taints else []

                if scaling_config_changed(desc, 0, 1, 0) or remove_labels or remove_taints or add_taints:
                    print(f"🔻 Scaling DOWN {cluster}/{ng} to 0/1/0 + powersave taint")

                    labels_payload = {}
                    if remove_labels:
                        labels_payload["removeLabels"] = remove_labels

                    taints_payload = {}
                    if add_taints:
                        taints_payload["addOrUpdateTaints"] = add_taints
                    if remove_taints:
                        taints_payload["removeTaints"] = remove_taints

                    try:
                        eks.update_nodegroup_config(
                            clusterName=cluster,
                            nodegroupName=ng,
                            scalingConfig={'minSize': 0, 'maxSize': 1, 'desiredSize': 0},
                            **({"labels": labels_payload} if labels_payload else {}),
                            **({"taints": taints_payload} if taints_payload else {})
                        )
                    except ClientError as e:
                        if e.response['Error']['Code'] == 'ResourceInUseException':
                            print(f"⚠️ Cannot scale DOWN {cluster}/{ng}, nodegroup not ACTIVE, skipping")
                        else:
                            raise
                else:
                    print(f"ℹ️ {cluster}/{ng} already DOWN, skipping")

            elif action == "up":
                cfg = load_scale_config(cluster, ng)
                if not cfg:
                    print(f"⚠️ No saved config for {cluster}/{ng}, skipping")
                    continue

                remove_taints = [powersave_taint] if powersave_taint in existing_taints else []

                if (scaling_config_changed(desc,
                                           int(cfg["scaling"]["min"]),
                                           int(cfg["scaling"]["max"]),
                                           int(cfg["scaling"]["desired"])) or
                        existing_labels != cfg.get("labels", {}) or
                        existing_taints != cfg.get("taints", [])):

                    print(f"🔺 Scaling UP {cluster}/{ng} + restoring labels/taints")

                    labels_payload = {}
                    if cfg.get("labels"):
                        labels_payload["addOrUpdateLabels"] = cfg["labels"]

                    taints_payload = {}
                    if cfg.get("taints"):
                        taints_payload["addOrUpdateTaints"] = cfg["taints"]
                    if remove_taints:
                        taints_payload["removeTaints"] = remove_taints

                    try:
                        eks.update_nodegroup_config(
                            clusterName=cluster,
                            nodegroupName=ng,
                            scalingConfig={
                                'minSize': int(cfg["scaling"]["min"]),
                                'maxSize': int(cfg["scaling"]["max"]),
                                'desiredSize': int(cfg["scaling"]["desired"])
                            },
                            **({"labels": labels_payload} if labels_payload else {}),
                            **({"taints": taints_payload} if taints_payload else {})
                        )
                    except ClientError as e:
                        if e.response['Error']['Code'] == 'ResourceInUseException':
                            print(f"⚠️ Cannot scale UP {cluster}/{ng}, nodegroup not ACTIVE, skipping")
                        else:
                            raise
                else:
                    print(f"ℹ️ {cluster}/{ng} already UP, skipping")

    return {"status": "ok", "action": action}

# lambda_handler(event={"action": "down"}, context=None)
